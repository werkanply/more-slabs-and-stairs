
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.moreslabsandstairs.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.moreslabsandstairs.block.EscalierbetongrisBlock;
import net.mcreator.moreslabsandstairs.block.EscalierBetonVertBlock;
import net.mcreator.moreslabsandstairs.block.EscalierBetonRougeBlock;
import net.mcreator.moreslabsandstairs.block.EscalierBetonRoseBlock;
import net.mcreator.moreslabsandstairs.block.EscalierBetonOrangeBlock;
import net.mcreator.moreslabsandstairs.block.EscalierBetonNoirBlock;
import net.mcreator.moreslabsandstairs.block.EscalierBetonMauveBlock;
import net.mcreator.moreslabsandstairs.block.EscalierBetonMagantaBlock;
import net.mcreator.moreslabsandstairs.block.EscalierBetonLimeBlock;
import net.mcreator.moreslabsandstairs.block.EscalierBetonJauneBlock;
import net.mcreator.moreslabsandstairs.block.EscalierBetonGrisClaireBlock;
import net.mcreator.moreslabsandstairs.block.EscalierBetonCyanBlock;
import net.mcreator.moreslabsandstairs.block.EscalierBetonBrunBlock;
import net.mcreator.moreslabsandstairs.block.EscalierBetonBleuClaireBlock;
import net.mcreator.moreslabsandstairs.block.EscalierBetonBleuBlock;
import net.mcreator.moreslabsandstairs.block.DalleBetonVertBlock;
import net.mcreator.moreslabsandstairs.block.DalleBetonRougeBlock;
import net.mcreator.moreslabsandstairs.block.DalleBetonRoseBlock;
import net.mcreator.moreslabsandstairs.block.DalleBetonOrangeBlock;
import net.mcreator.moreslabsandstairs.block.DalleBetonNoirBlock;
import net.mcreator.moreslabsandstairs.block.DalleBetonMauveBlock;
import net.mcreator.moreslabsandstairs.block.DalleBetonMagantaBlock;
import net.mcreator.moreslabsandstairs.block.DalleBetonLimeBlock;
import net.mcreator.moreslabsandstairs.block.DalleBetonJauneBlock;
import net.mcreator.moreslabsandstairs.block.DalleBetonGrisClaireBlock;
import net.mcreator.moreslabsandstairs.block.DalleBetonGrisBlock;
import net.mcreator.moreslabsandstairs.block.DalleBetonCyanBlock;
import net.mcreator.moreslabsandstairs.block.DalleBetonBrunBlock;
import net.mcreator.moreslabsandstairs.block.DalleBetonBleuClaireBlock;
import net.mcreator.moreslabsandstairs.block.DalleBetonBleuBlock;
import net.mcreator.moreslabsandstairs.MoreSlabsAndStairsMod;

public class MoreSlabsAndStairsModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, MoreSlabsAndStairsMod.MODID);
	public static final RegistryObject<Block> ESCALIERBETONGRIS = REGISTRY.register("escalierbetongris", () -> new EscalierbetongrisBlock());
	public static final RegistryObject<Block> ESCALIER_BETON_NOIR = REGISTRY.register("escalier_beton_noir", () -> new EscalierBetonNoirBlock());
	public static final RegistryObject<Block> ESCALIER_BETON_ROUGE = REGISTRY.register("escalier_beton_rouge", () -> new EscalierBetonRougeBlock());
	public static final RegistryObject<Block> ESCALIER_BETON_BLEU = REGISTRY.register("escalier_beton_bleu", () -> new EscalierBetonBleuBlock());
	public static final RegistryObject<Block> ESCALIER_BETON_BRUN = REGISTRY.register("escalier_beton_brun", () -> new EscalierBetonBrunBlock());
	public static final RegistryObject<Block> ESCALIER_BETON_CYAN = REGISTRY.register("escalier_beton_cyan", () -> new EscalierBetonCyanBlock());
	public static final RegistryObject<Block> ESCALIER_BETON_VERT = REGISTRY.register("escalier_beton_vert", () -> new EscalierBetonVertBlock());
	public static final RegistryObject<Block> ESCALIER_BETON_BLEU_CLAIRE = REGISTRY.register("escalier_beton_bleu_claire",
			() -> new EscalierBetonBleuClaireBlock());
	public static final RegistryObject<Block> ESCALIER_BETON_GRIS_CLAIRE = REGISTRY.register("escalier_beton_gris_claire",
			() -> new EscalierBetonGrisClaireBlock());
	public static final RegistryObject<Block> ESCALIER_BETON_LIME = REGISTRY.register("escalier_beton_lime", () -> new EscalierBetonLimeBlock());
	public static final RegistryObject<Block> ESCALIER_BETON_MAGANTA = REGISTRY.register("escalier_beton_maganta",
			() -> new EscalierBetonMagantaBlock());
	public static final RegistryObject<Block> ESCALIER_BETON_ORANGE = REGISTRY.register("escalier_beton_orange",
			() -> new EscalierBetonOrangeBlock());
	public static final RegistryObject<Block> ESCALIER_BETON_ROSE = REGISTRY.register("escalier_beton_rose", () -> new EscalierBetonRoseBlock());
	public static final RegistryObject<Block> ESCALIER_BETON_MAUVE = REGISTRY.register("escalier_beton_mauve", () -> new EscalierBetonMauveBlock());
	public static final RegistryObject<Block> ESCALIER_BETON_JAUNE = REGISTRY.register("escalier_beton_jaune", () -> new EscalierBetonJauneBlock());
	public static final RegistryObject<Block> DALLE_BETON_GRIS = REGISTRY.register("dalle_beton_gris", () -> new DalleBetonGrisBlock());
	public static final RegistryObject<Block> DALLE_BETON_NOIR = REGISTRY.register("dalle_beton_noir", () -> new DalleBetonNoirBlock());
	public static final RegistryObject<Block> DALLE_BETON_ROUGE = REGISTRY.register("dalle_beton_rouge", () -> new DalleBetonRougeBlock());
	public static final RegistryObject<Block> DALLE_BETON_BLEU = REGISTRY.register("dalle_beton_bleu", () -> new DalleBetonBleuBlock());
	public static final RegistryObject<Block> DALLE_BETON_BRUN = REGISTRY.register("dalle_beton_brun", () -> new DalleBetonBrunBlock());
	public static final RegistryObject<Block> DALLE_BETON_CYAN = REGISTRY.register("dalle_beton_cyan", () -> new DalleBetonCyanBlock());
	public static final RegistryObject<Block> DALLE_BETON_VERT = REGISTRY.register("dalle_beton_vert", () -> new DalleBetonVertBlock());
	public static final RegistryObject<Block> DALLE_BETON_BLEU_CLAIRE = REGISTRY.register("dalle_beton_bleu_claire",
			() -> new DalleBetonBleuClaireBlock());
	public static final RegistryObject<Block> DALLE_BETON_GRIS_CLAIRE = REGISTRY.register("dalle_beton_gris_claire",
			() -> new DalleBetonGrisClaireBlock());
	public static final RegistryObject<Block> DALLE_BETON_LIME = REGISTRY.register("dalle_beton_lime", () -> new DalleBetonLimeBlock());
	public static final RegistryObject<Block> DALLE_BETON_MAGANTA = REGISTRY.register("dalle_beton_maganta", () -> new DalleBetonMagantaBlock());
	public static final RegistryObject<Block> DALLE_BETON_ORANGE = REGISTRY.register("dalle_beton_orange", () -> new DalleBetonOrangeBlock());
	public static final RegistryObject<Block> DALLE_BETON_ROSE = REGISTRY.register("dalle_beton_rose", () -> new DalleBetonRoseBlock());
	public static final RegistryObject<Block> DALLE_BETON_MAUVE = REGISTRY.register("dalle_beton_mauve", () -> new DalleBetonMauveBlock());
	public static final RegistryObject<Block> DALLE_BETON_JAUNE = REGISTRY.register("dalle_beton_jaune", () -> new DalleBetonJauneBlock());
}
