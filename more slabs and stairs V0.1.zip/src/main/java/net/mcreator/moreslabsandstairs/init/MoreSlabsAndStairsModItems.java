
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.moreslabsandstairs.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

import net.mcreator.moreslabsandstairs.MoreSlabsAndStairsMod;

public class MoreSlabsAndStairsModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, MoreSlabsAndStairsMod.MODID);
	public static final RegistryObject<Item> ESCALIERBETONGRIS = block(MoreSlabsAndStairsModBlocks.ESCALIERBETONGRIS,
			CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> ESCALIER_BETON_NOIR = block(MoreSlabsAndStairsModBlocks.ESCALIER_BETON_NOIR,
			CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> ESCALIER_BETON_ROUGE = block(MoreSlabsAndStairsModBlocks.ESCALIER_BETON_ROUGE,
			CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> ESCALIER_BETON_BLEU = block(MoreSlabsAndStairsModBlocks.ESCALIER_BETON_BLEU,
			CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> ESCALIER_BETON_BRUN = block(MoreSlabsAndStairsModBlocks.ESCALIER_BETON_BRUN,
			CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> ESCALIER_BETON_CYAN = block(MoreSlabsAndStairsModBlocks.ESCALIER_BETON_CYAN,
			CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> ESCALIER_BETON_VERT = block(MoreSlabsAndStairsModBlocks.ESCALIER_BETON_VERT,
			CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> ESCALIER_BETON_BLEU_CLAIRE = block(MoreSlabsAndStairsModBlocks.ESCALIER_BETON_BLEU_CLAIRE,
			CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> ESCALIER_BETON_GRIS_CLAIRE = block(MoreSlabsAndStairsModBlocks.ESCALIER_BETON_GRIS_CLAIRE,
			CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> ESCALIER_BETON_LIME = block(MoreSlabsAndStairsModBlocks.ESCALIER_BETON_LIME,
			CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> ESCALIER_BETON_MAGANTA = block(MoreSlabsAndStairsModBlocks.ESCALIER_BETON_MAGANTA,
			CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> ESCALIER_BETON_ORANGE = block(MoreSlabsAndStairsModBlocks.ESCALIER_BETON_ORANGE,
			CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> ESCALIER_BETON_ROSE = block(MoreSlabsAndStairsModBlocks.ESCALIER_BETON_ROSE,
			CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> ESCALIER_BETON_MAUVE = block(MoreSlabsAndStairsModBlocks.ESCALIER_BETON_MAUVE,
			CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> ESCALIER_BETON_JAUNE = block(MoreSlabsAndStairsModBlocks.ESCALIER_BETON_JAUNE,
			CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> DALLE_BETON_GRIS = block(MoreSlabsAndStairsModBlocks.DALLE_BETON_GRIS,
			CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> DALLE_BETON_NOIR = block(MoreSlabsAndStairsModBlocks.DALLE_BETON_NOIR,
			CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> DALLE_BETON_ROUGE = block(MoreSlabsAndStairsModBlocks.DALLE_BETON_ROUGE,
			CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> DALLE_BETON_BLEU = block(MoreSlabsAndStairsModBlocks.DALLE_BETON_BLEU,
			CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> DALLE_BETON_BRUN = block(MoreSlabsAndStairsModBlocks.DALLE_BETON_BRUN,
			CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> DALLE_BETON_CYAN = block(MoreSlabsAndStairsModBlocks.DALLE_BETON_CYAN,
			CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> DALLE_BETON_VERT = block(MoreSlabsAndStairsModBlocks.DALLE_BETON_VERT,
			CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> DALLE_BETON_BLEU_CLAIRE = block(MoreSlabsAndStairsModBlocks.DALLE_BETON_BLEU_CLAIRE,
			CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> DALLE_BETON_GRIS_CLAIRE = block(MoreSlabsAndStairsModBlocks.DALLE_BETON_GRIS_CLAIRE,
			CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> DALLE_BETON_LIME = block(MoreSlabsAndStairsModBlocks.DALLE_BETON_LIME,
			CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> DALLE_BETON_MAGANTA = block(MoreSlabsAndStairsModBlocks.DALLE_BETON_MAGANTA,
			CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> DALLE_BETON_ORANGE = block(MoreSlabsAndStairsModBlocks.DALLE_BETON_ORANGE,
			CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> DALLE_BETON_ROSE = block(MoreSlabsAndStairsModBlocks.DALLE_BETON_ROSE,
			CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> DALLE_BETON_MAUVE = block(MoreSlabsAndStairsModBlocks.DALLE_BETON_MAUVE,
			CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> DALLE_BETON_JAUNE = block(MoreSlabsAndStairsModBlocks.DALLE_BETON_JAUNE,
			CreativeModeTab.TAB_BUILDING_BLOCKS);

	private static RegistryObject<Item> block(RegistryObject<Block> block, CreativeModeTab tab) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties().tab(tab)));
	}
}
